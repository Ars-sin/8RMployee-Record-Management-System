<?php
// --- Live Employee Search Endpoint for the Modal ---
if (isset($_GET['action']) && $_GET['action'] == 'search_employees') {
    $servername = "localhost";
    $username = "u987478351_ruth";
    $password = "Qwertyuiop143!";
    $dbname = "u987478351_8rm_admin";
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    header('Content-Type: application/json');
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['error' => 'Database connection failed']);
        exit();
    }
    
    $searchTerm = $_GET['query'] ?? '';
    $results = [];

    if (trim($searchTerm) !== '') {
        $sql = "SELECT id, CONCAT(last_name, ', ', first_name) as name 
                FROM employee 
                WHERE CONCAT(last_name, ', ', first_name) LIKE ? AND status = 'Active' 
                ORDER BY last_name, first_name ASC LIMIT 10";
        
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $likeTerm = "%" . $searchTerm . "%";
            $stmt->bind_param("s", $likeTerm);
            if ($stmt->execute()) {
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    $results[] = $row;
                }
            }
            $stmt->close();
        }
    }
    
    $conn->close();
    echo json_encode($results);
    exit();
}

// --- PHP LOGIC FOR FULL PAGE LOAD STARTS HERE ---
require_once 'check_auth.php';

// --- Database Connection for Page ---
$servername = "localhost";
$username = "u987478351_ruth";
$password = "Qwertyuiop143!";
$dbname = "u987478351_8rm_admin";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

// --- Filter and Type Setup ---
$valid_types = ['Pag-IBIG', 'SSS', 'PhilHealth'];
$active_type = $_GET['type'] ?? 'Pag-IBIG';
if (!in_array($active_type, $valid_types)) {
    $active_type = 'Pag-IBIG';
}

$id_column_name = ($active_type == 'Pag-IBIG') ? 'pagibig_no' : strtolower($active_type) . '_no';

$filter_month = $_GET['month'] ?? date('n');
$filter_year = $_GET['year'] ?? date('Y');
$months = [];
for ($m = 1; $m <= 12; $m++) {
    $months[$m] = date('F', mktime(0, 0, 0, $m, 1));
}

// --- SERVER-SIDE SEARCH AND PAGINATION LOGIC ---
$records_per_page = 10;
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($current_page < 1) $current_page = 1;
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';

$base_sql_from = "FROM remittances r JOIN employee e ON r.employee_id = e.id";
$where_clauses = ["r.remittance_type = ?", "r.remittance_month = ?", "r.remittance_year = ?"];
$params = [$active_type, $filter_month, $filter_year];
$param_types = 'sii';

if (!empty($search_term)) {
    $where_clauses[] = "CONCAT(e.last_name, ', ', e.first_name) LIKE ?";
    $params[] = "%" . $search_term . "%";
    $param_types .= 's';
}

$sql_where = " WHERE " . implode(" AND ", $where_clauses);

// Get total records for pagination
$total_sql = "SELECT COUNT(r.id) AS total " . $base_sql_from . $sql_where;
$stmt_total = $conn->prepare($total_sql);
$stmt_total->bind_param($param_types, ...$params);
$stmt_total->execute();
$total_result = $stmt_total->get_result();
$total_row = $total_result->fetch_assoc();
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $records_per_page);

if ($current_page > $total_pages && $total_pages > 0) $current_page = $total_pages;
$offset = ($current_page - 1) * $records_per_page;

// Get records for the current page
$main_sql = "SELECT CONCAT(e.last_name, ', ', e.first_name) as name, e.{$id_column_name} as id_no, r.status, r.amount " . $base_sql_from . $sql_where . " ORDER BY r.id DESC LIMIT ? OFFSET ?";
$main_params = $params;
$main_params[] = $records_per_page;
$main_params[] = $offset;
$main_param_types = $param_types . 'ii';

$stmt = $conn->prepare($main_sql);
$stmt->bind_param($main_param_types, ...$main_params);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($active_type); ?> - Government Beneficiary</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="/logo.png.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@10.2.7/dist/css/autoComplete.min.css">

    <style>
        body { 
            margin: 0; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; 
            color: #1a202c; 
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            line-height: 1.6;
        }
        
        .dashboard-container { 
            display: flex; 
            width: 100%; 
            height: 100vh; 
            overflow: hidden; 
        }
        
       /* Sidebar Improvements */
        .sidebar { 
            width: 280px; 
            flex-shrink: 0; 
            background: linear-gradient(180deg, #ffffff 0%, #fefcf5 100%);
            padding: 24px; 
            display: flex; 
            flex-direction: column; 
            border-right: 1px solid #e2e8f0;
            box-shadow: 4px 0 12px rgba(0, 0, 0, 0.05);
            
        }

        .logo { 
            display: flex; 
            align-items: center; 
            margin-bottom: 48px; 
            padding: 0 12px; 
        }
        .logo img { 
            width: 44px; 
            height: 44px; 
            margin-right: 12px; 
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        .logo-text { display: flex; flex-direction: column; }
        .logo-text .main-name { 
            font-size: 26px; 
            font-weight: 800; 
            display: flex; 
            align-items: center; 
            letter-spacing: -0.5px;
        }
        .logo-8 { color: #22c55e; }
        .logo-rm { color: #1e3a8a; margin-left: 0.2rem; }
        .sub-name { 
            font-size: 11px; 
            color: #f59e0b; 
            font-weight: 600; 
            margin-top: 2px;
            letter-spacing: 0.3px;
        }
        
        .navigation {
            flex-grow: 1; 
            display: flex;
            flex-direction: column;
        }
        .navigation ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .navigation li a {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            text-decoration: none;
            color: #4a5568;
            font-weight: 500;
            border-radius: 12px;
            margin-bottom: 6px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            font-size: 15px;
        }
        .navigation li a i { 
            margin-right: 16px; 
            font-size: 18px; 
            width: 20px; 
            text-align: center; 
        }
        .navigation li a:hover { 
            background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e0 100%);
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .navigation li.active > a { 
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
            color: white; 
            box-shadow: 0 4px 16px rgba(30, 58, 138, 0.3);
            
        }

        .logout-item {
            margin-top: auto;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            width: 280px;
        }
        .logout-item a {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            text-decoration: none;
            background: linear-gradient(135deg, #fed7d7 0%, #feb2b2 100%);
            color: #c53030;
            font-weight: 600;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-size: 15px;
        }
        .logout-item a:hover {
            background: linear-gradient(135deg, #feb2b2 0%, #fc8181 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(197, 48, 48, 0.2);
        }

        /* Main Content Improvements */
        .main-content { 
            flex-grow: 1; 
            padding: 24px; /* ADJUSTED */
            display: flex; 
            flex-direction: column; 
            overflow-y: auto;
            background: transparent;
        }

        /* ADJUSTED: Combined Header Block */
        .main-header { 
            flex-shrink: 0;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
            margin-bottom: 24px; /* ADJUSTED */
        }

        .tabs { 
            display: flex; 
            gap: 20px; 
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 16px;
        }
        .tab-link { 
            text-decoration: none; 
            font-size: 16px; 
            color: #718096; 
            font-weight: 600; 
            padding: 12px 15px;
            border-bottom: 3px solid transparent; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            white-space: nowrap;
        }
        .tab-link:hover {
            color: #4a5568;
            transform: translateY(-1px);
        }
        .tab-link.active { 
            color: #1e3a8a; 
            border-bottom-color: #1e3a8a; 
        }
        .tab-link.active::before {
            content: '';
            position: absolute;
            bottom: -3px;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #1e3a8a, #3b82f6);
            border-radius: 2px;
        }
        
        /* NEW: Wrapper for title and controls */
        .header-main-controls {
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            flex-wrap: wrap; 
            gap: 20px;
            padding-top: 24px;
        }

        .page-title { 
            font-size: 40px; /* ADJUSTED */
            font-weight: 900; 
            color: #1a202c; 
            margin: 0; 
            line-height: 1; 
            background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -1px;
        }

        .controls { 
            display: flex; 
            align-items: center; 
            gap: 16px; 
            flex-wrap: wrap;
        }

        /* Search Bar Improvements */
        .search-bar { 
            position: relative; 
            display: flex; 
            align-items: center; 
        }
        .search-bar i { 
            position: absolute; 
            left: 16px; 
            top: 50%; 
            transform: translateY(-50%); 
            color: #a0aec0; 
            font-size: 16px;
        }
        .search-bar input { 
            width: 240px; 
            padding: 0px 16px 0px 44px; 
            border: 2px solid #e2e8f0; 
            border-radius: 12px; 
            font-size: 14px; 
            background: rgba(255, 255, 255, 0.9); 
            height: 44px; 
            line-height: 1; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .search-bar input:focus {
            outline: none;
            border-color: #3b82f6;
            background: white;
            box-shadow: 0 4px 16px rgba(59, 130, 246, 0.15);
            transform: translateY(-1px);
        }

        /* Form Controls */
        .period-filter-form { 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            margin: 0; 
        }
        .period-filter-form label { 
            font-size: 14px; 
            color: #4a5568; 
            line-height: 44px; 
            height: 44px; 
            display: flex; 
            align-items: center; 
            white-space: nowrap; 
            font-weight: 600;
        }
        .period-filter-form select { 
            padding: 12px 16px; 
            border: 2px solid #e2e8f0; 
            border-radius: 12px; 
            font-size: 14px; 
            background: rgba(255, 255, 255, 0.9); 
            appearance: none; 
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3E%3C/svg%3E"); 
            background-repeat: no-repeat; 
            background-position: right 12px center; 
            background-size: 16px; 
            padding-right: 40px; 
            height: 44px; 
            line-height: 1; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            font-weight: 500;
        }
        .period-filter-form select:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 4px 16px rgba(59, 130, 246, 0.15);
        }

        /* Button Improvements */
        .action-buttons { 
            display: flex; 
            gap: 12px; 
            align-items: center; 
        }
        .btn { 
            padding: 0 24px; 
            border: none; 
            border-radius: 12px; 
            font-weight: 700; 
            cursor: pointer; 
            text-transform: uppercase; 
            font-size: 12px; 
            height: 44px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            line-height: 1; 
            text-decoration: none; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        }
        .btn-add { 
            background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); 
            color: white; 
        }
        .btn-add:hover {
            background: linear-gradient(135deg, #1e40af 0%, #2563eb 100%);
        }
        .btn-export { 
            background: linear-gradient(135deg, #4a5568 0%, #718096 100%); 
            color: white; 
        }
        .btn-export:hover {
            background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
        }
        
        .btn-import { 
            background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); 
            color: white; 
        }
        .btn-import:hover {
            background: linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%);
        }

        /* Table Wrapper and Pagination */
        .content-wrapper {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            background: rgba(255, 255, 255, 0.95); 
            border: none; 
            border-radius: 20px; 
            overflow: hidden;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.08);
            backdrop-filter: blur(10px);
        }

        .table-container { 
            flex-grow: 1;
            overflow-x: auto;
        }

        table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        th, td { 
            padding: 20px 24px; 
            text-align: left; 
            border-bottom: 1px solid #f1f5f9; 
            vertical-align: middle; 
            white-space: nowrap;
        }
        th { 
            background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%); 
            color: #1a202c; 
            font-weight: 700; 
            font-size: 13px; 
            text-transform: uppercase; 
            letter-spacing: 0.8px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        td { 
            font-size: 15px; 
            color: #4a5568; 
            font-weight: 500;
        }
        tbody tr {
            transition: all 0.2s ease;
        }
        tbody tr:hover { 
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); 
            transform: translateX(4px);
        }
        .status-unpaid { 
            color: #dc2626; 
            font-weight: 600; 
            padding: 4px 8px;
            background: rgba(220, 38, 38, 0.1);
            border-radius: 6px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .status-paid { 
            color: #16a34a; 
            font-weight: 600; 
            padding: 4px 8px;
            background: rgba(34, 197, 94, 0.1);
            border-radius: 6px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .pagination-container { 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            padding: 24px 0; 
            flex-shrink: 0; 
            border-top: 1px solid rgba(226, 232, 240, 0.5);
        }
        .pagination-container a, .pagination-container span { 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            text-decoration: none; 
            color: #475569; 
            border: 2px solid rgba(226, 232, 240, 0.6);
            background: rgba(255, 255, 255, 0.9);
            margin: 0 4px; 
            border-radius: 12px; 
            min-width: 40px; 
            height: 40px; 
            font-size: 14px; 
            font-weight: 600;
            transition: all 0.2s ease;
            backdrop-filter: blur(10px);
        }
        .pagination-container a:hover { 
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            border-color: transparent;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.25);
        }
        .pagination-container a.active { 
            background: linear-gradient(135deg, #1e3a8a 0%, #3730a3 100%);
            color: white; 
            border-color: transparent;
            box-shadow: 0 4px 16px rgba(30, 58, 138, 0.3);
        }
        .pagination-container span.disabled { 
            color: #cbd5e1; 
            border-color: #f1f5f9; 
            pointer-events: none;
            background: #f8fafc;
        }
        .pagination-container span.ellipsis { 
            border: none; 
            background: none; 
            padding: 0 8px; 
            color: #94a3b8;
        }

        /* Modal Improvements */
        .modal { 
            display: none; 
            position: fixed; 
            z-index: 1000; 
            left: 0; 
            top: 0; 
            width: 100%; 
            height: 100%; 
            overflow: auto; 
            background: rgba(0, 0, 0, 0.6); 
            justify-content: center; 
            align-items: center; 
            backdrop-filter: blur(8px);
        }
        .modal-content { 
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); 
            margin: auto; 
            padding: 32px; 
            border-radius: 24px; 
            width: 90%; 
            max-width: 650px; 
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.15); 
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .modal-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-bottom: 2px solid #e2e8f0; 
            padding-bottom: 16px; 
            margin-bottom: 24px; 
        }
        .modal-header h2 { 
            margin: 0; 
            font-size: 28px; 
            font-weight: 800;
            color: #1a202c;
            letter-spacing: -0.5px;
        }
        .close-button { 
            color: #a0aec0; 
            font-size: 32px; 
            font-weight: bold; 
            cursor: pointer; 
            transition: all 0.3s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
        }
        .close-button:hover { 
            color: #e53e3e; 
            background: rgba(229, 62, 62, 0.1);
            transform: rotate(90deg);
        }

        .modal-body .form-group { 
            display: flex; 
            flex-direction: column; 
            margin-bottom: 20px; 
        }
        .modal-body label { 
            margin-bottom: 8px; 
            font-size: 14px; 
            font-weight: 600; 
            color: #2d3748;
        }
        .modal-body input, .modal-body select { 
            padding: 14px 16px; 
            border: 2px solid #e2e8f0; 
            border-radius: 12px; 
            font-size: 14px; 
            width: 100%; 
            height: 48px; 
            box-sizing: border-box; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: rgba(255, 255, 255, 0.8);
            font-weight: 500;
        }
        .modal-body input:focus, .modal-body select:focus {
            outline: none;
            border-color: #3b82f6;
            background: white;
            box-shadow: 0 4px 16px rgba(59, 130, 246, 0.15);
            transform: translateY(-1px);
        }

        .modal-footer { 
            display: flex; 
            justify-content: flex-end; 
            margin-top: 32px; 
        }
        
        .btn-remove-line { 
            background: transparent; 
            border: none; 
            color: #cbd5e0; 
            cursor: pointer; 
            font-size: 18px; 
            width: 40px; 
            height: 40px; /* square */
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            border-radius: 8px; 
            box-sizing: border-box;
            margin-top: 11px;
        }

        .btn-remove-line:hover { 
            color: #e53e3e; 
            background: rgba(229, 62, 62, 0.1);
            transform: scale(1.1);
        }
        
        .inline-form-groups { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 20px; 
            padding-bottom: 24px; 
            margin-bottom: 24px; 
            border-bottom: 2px solid #e2e8f0; 
        }
        
        .remittance-line { 
            display: grid; 
            grid-template-columns: 1fr 1fr 40px; /* fixed 40px for trash column */
            gap: 20px; 
            align-items: center; 
            margin-bottom: 20px; 
        }
        
        .btn-add-more {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 20px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 16px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-block;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.25);
        }
        .btn-add-more:hover { 
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(34, 197, 94, 0.35);
        }

        /* Autocomplete Improvements */
        .search-input-wrapper { 
            position: relative; 
        }
        .search-input-wrapper .fa-search { 
            position: absolute; 
            left: 16px; 
            top: 50%; 
            transform: translateY(-50%); 
            color: #a0aec0; 
            font-size: 16px;
        }
        div.autoComplete_wrapper { 
            width: 100%; 
        }
        #employee-search, .employee-search { 
            padding-left: 44px !important; 
            color: #2d3748; 
        }
        #employee-search::placeholder, .employee-search::placeholder { 
            color: #a0aec0; 
            opacity: 1; 
        }
        div.autoComplete_wrapper > input#employee-search:focus,
        div.autoComplete_wrapper > input.employee-search:focus { 
            outline: none; 
            border-color: #3b82f6; 
            box-shadow: 0 4px 16px rgba(59, 130, 246, 0.15); 
        }
        div.autoComplete_wrapper > svg { 
            display: none !important; 
        }
        #autoComplete_list { 
            border: 2px solid #e2e8f0; 
            border-radius: 12px; 
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15); 
            margin-top: 8px; 
            background: white;
            backdrop-filter: blur(10px);
            z-index: 1100; /* Ensure it's above modal content */
        }
        #autoComplete_list .autoComplete_result { 
            padding: 12px 16px; 
            font-size: 14px; 
            color: #4a5568; 
            cursor: pointer; 
            transition: all 0.2s ease;
            border-bottom: 1px solid #f1f5f9;
        }
        #autoComplete_list .autoComplete_result:last-child {
            border-bottom: none;
        }
        #autoComplete_list .autoComplete_result:hover {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        }
        #autoComplete_list .autoComplete_result mark { 
            background-color: transparent; 
            color: inherit; 
            font-weight: 700; 
            padding: 0; 
            color: #3b82f6;
        }
        #autoComplete_list .autoComplete_selected { 
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); 
            color: white; 
        }
        #autoComplete_list .autoComplete_selected mark { 
            color: white; 
        }

        /* Additional styles for employee blocks */
        .employee-block {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            border: 2px solid #e2e8f0;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            position: relative;
        }

        .employee-block-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid #e2e8f0;
        }

        .employee-block-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
            color: #1e3a8a;
        }

        .btn-remove-employee {
            background: transparent;
            border: 2px solid #e2e8f0;
            color: #ef4444;
            cursor: pointer;
            font-size: 16px;
            width: 36px;
            height: 36px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
        }

        .btn-remove-employee:hover {
            background: #fee2e2;
            border-color: #ef4444;
            transform: scale(1.1);
        }

        .btn-add-more-remittance {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 2px 8px rgba(34, 197, 94, 0.25);
        }

        .btn-add-more-remittance:hover {
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.35);
        }
        
                /* Toast Notification Styles - Add this BEFORE the @media queries */
        .toast-notification {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%) translateY(-100px);
            background: white;
            border-left: 5px solid #22c55e;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 9999;
            opacity: 0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            min-width: 400px;
            max-width: 500px;
        }
        
        .toast-notification.show {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
        
        .toast-notification.error {
            border-left-color: #ef4444;
        }
        
        .toast-notification.error .toast-icon {
            background: #ef4444;
            color: white;
        }
        
        .toast-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #22c55e;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        
        .toast-content {
            flex: 1;
            color: #1f2937;
            font-size: 15px;
            font-weight: 500;
            line-height: 1.5;
        }
        
        .toast-close {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            background: transparent;
            border: none;
            color: #9ca3af;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: all 0.2s ease;
            flex-shrink: 0;
            font-weight: 300;
        }
        
        .toast-close:hover {
            background: #f3f4f6;
            color: #6b7280;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                padding: 24px 32px;
            }
            .page-title {
                font-size: 36px;
            }
        }

        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                padding: 16px;
                height: auto;
            }
            .main-content {
                padding: 16px 20px;
            }
            .header-main-controls {
                flex-direction: column;
                align-items: stretch;
            }
            .controls {
                flex-wrap: wrap;
                justify-content: center;
            }
            .search-bar input {
                width: 100%;
            }
            .inline-form-groups {
                grid-template-columns: 1fr;
            }
            .remittance-line {
                grid-template-columns: 1fr;
                gap: 12px;
            }
            .remittance-line .btn-remove-line {
                margin-top: 0;
                justify-content: flex-end;
            }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <aside class="sidebar">
        <div class="logo"> <img src="logo.png.png" alt="8 RM Logo"> <div class="logo-text"> <div class="main-name"><span class="logo-8">8</span><span class="logo-rm">R M</span></div> <span class="sub-name">Utility Projects Construction</span> </div> </div>
        <nav class="navigation">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                <li><a href="employee.php"><i class="fas fa-users"></i> Employee Information</a></li>
                <li class="active"><a href="government_beneficiary.php"><i class="fas fa-file-invoice"></i> Government Remittances</a></li>
                <li><a href="changelog.php"><i class="fas fa-book"></i> Changelog</a></li>
                <li><a href="employee_archive.php"><i class="fas fa-archive"></i> Employee Archive</a></li>
                <li><a href="overview.php"><i class="fas fa-chart-bar"></i> Overview</a></li>
            </ul>
            <div class="logout-item">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <!-- ADJUSTED: Combined Header -->
        <div class="main-header">
            <div class="tabs">
                <a href="government_beneficiary.php?type=Pag-IBIG" class="tab-link <?php if($active_type == 'Pag-IBIG') echo 'active'; ?>">Pag-IBIG</a>
                <a href="government_beneficiary.php?type=SSS" class="tab-link <?php if($active_type == 'SSS') echo 'active'; ?>">SSS</a>
                <a href="government_beneficiary.php?type=PhilHealth" class="tab-link <?php if($active_type == 'PhilHealth') echo 'active'; ?>">PhilHealth</a>
            </div>
            <div class="header-main-controls">
                <h1 class="page-title"><?php echo htmlspecialchars($active_type); ?></h1>
                <div class="controls">
                    <form method="GET" action="government_beneficiary.php" class="search-bar">
                        <i class="fas fa-search"></i>
                        <input type="hidden" name="type" value="<?php echo htmlspecialchars($active_type); ?>">
                        <input type="hidden" name="month" value="<?php echo htmlspecialchars($filter_month); ?>">
                        <input type="hidden" name="year" value="<?php echo htmlspecialchars($filter_year); ?>">
                        <input type="text" name="search" id="searchInput" placeholder="Search Name..." value="<?php echo htmlspecialchars($search_term); ?>">
                    </form>
            
                    <form class="period-filter-form" action="government_beneficiary.php" method="GET">
                        <input type="hidden" name="type" value="<?php echo htmlspecialchars($active_type); ?>">
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_term); ?>">
                        
                        <label for="monthFilter">Month:</label>
                        <select name="month" id="monthFilter">
                            <?php foreach($months as $num => $name): ?>
                            <option value="<?php echo $num; ?>" <?php if ($num == $filter_month) echo 'selected'; ?>><?php echo $name; ?></option>
                            <?php endforeach; ?>
                        </select>

                        <label for="yearFilter">Year:</label>
                        <select name="year" id="yearFilter">
                            <?php for($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                            <option value="<?php echo $y; ?>" <?php if ($y == $filter_year) echo 'selected'; ?>><?php echo $y; ?></option>
                            <?php endfor; ?>
                        </select>
                    </form>

                    <div class="action-buttons">
                        <button id="openModalBtn" class="btn btn-add">ADD</button>
                        <button id="openImportModalBtn" class="btn btn-import">IMPORT</button>
                        <a href="export_remittances.php?<?php echo http_build_query(['type' => $active_type, 'month' => $filter_month, 'year' => $filter_year, 'search' => $search_term]); ?>" class="btn btn-export">EXPORT</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-wrapper">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>No.</th>
                            <th>Status</th>
                            <th>Amount</th>
                            <th>Month/Year Covered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $status_class = ($row['status'] == 'Paid') ? 'status-paid' : 'status-unpaid';
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['id_no']) . "</td>";
                                echo "<td><span class='{$status_class}'>" . htmlspecialchars($row['status']) . "</span></td>";
                                echo "<td>₱ " . number_format($row['amount'], 2) . "</td>";
                                echo "<td>" . str_pad($filter_month, 2, '0', STR_PAD_LEFT) . "-{$filter_year}</td>";
                                echo "</tr>";
                            }
                        } else { 
                            echo "<tr><td colspan='5' style='text-align:center; padding: 40px;'>No remittances found for this period.</td></tr>"; 
                        }
                        $stmt->close();
                        $stmt_total->close();
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        
            <?php if ($total_pages > 1): ?>
            <nav class="pagination-container">
                <?php
                    $query_params = [
                        'type' => $active_type,
                        'month' => $filter_month,
                        'year' => $filter_year,
                        'search' => $search_term
                    ];
                    
                    if ($current_page > 1) { $query_params['page'] = 1; echo '<a href="?' . http_build_query($query_params) . '">&laquo;</a>'; } else { echo '<span class="disabled">&laquo;</span>'; }
                    if ($current_page > 1) { $query_params['page'] = $current_page - 1; echo '<a href="?' . http_build_query($query_params) . '">&lt;</a>'; } else { echo '<span class="disabled">&lt;</span>'; }
                    
                    $links_to_show = 2; $start = max(1, $current_page - $links_to_show); $end = min($total_pages, $current_page + $links_to_show);
                    
                    if ($start > 1) { $query_params['page'] = 1; echo '<a href="?' . http_build_query($query_params) . '">1</a>'; if ($start > 2) { echo '<span class="ellipsis">...</span>'; } }
                    
                    for ($i = $start; $i <= $end; $i++) { $query_params['page'] = $i; $active_class = ($i == $current_page) ? 'active' : ''; echo '<a href="?' . http_build_query($query_params) . '" class="' . $active_class . '">' . $i . '</a>'; }
                    
                    if ($end < $total_pages) { if ($end < $total_pages - 1) { echo '<span class="ellipsis">...</span>'; } $query_params['page'] = $total_pages; echo '<a href="?' . http_build_query($query_params) . '">' . $total_pages . '</a>'; }
                    
                    if ($current_page < $total_pages) { $query_params['page'] = $current_page + 1; echo '<a href="?' . http_build_query($query_params) . '">&gt;</a>'; } else { echo '<span class="disabled">&gt;</span>'; }
                    if ($current_page < $total_pages) { $query_params['page'] = $total_pages; echo '<a href="?' . http_build_query($query_params) . '">&raquo;</a>'; } else { echo '<span class="disabled">&raquo;</span>'; }
                ?>
            </nav>
            <?php endif; ?>
        </div>
        
        <!-- Add Remittances Modal - Updated for Multiple Employees -->
        <div id="addRemittanceModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>ADD REMITTANCES</h2>
                    <span class="close-button">&times;</span>
                </div>
                <div class="modal-body">
                    <form id="addRemittanceForm" action="add_remittance_action.php" method="POST" novalidate>
                        <!-- Period Selection (applies to all employees) -->
                        <div class="inline-form-groups">
                            <div class="form-group">
                                <label>Month Covered:</label>
                                <select name="month_covered" required>
                                    <?php foreach($months as $num => $name): ?>
                                    <option value="<?php echo $num; ?>" <?php if($num == $filter_month) echo 'selected'; ?>><?php echo $name; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Year Covered:</label>
                                <select name="year_covered" required>
                                    <?php for($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                                    <option value="<?php echo $y; ?>" <?php if($y == $filter_year) echo 'selected'; ?>><?php echo $y; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>

                        <!-- Container for Multiple Employees -->
                        <div id="employees-container">
                            <!-- First Employee Block -->
                            <div class="employee-block">
                                <div class="employee-block-header">
                                    <h3>Employee #1</h3>
                                    <button type="button" class="btn-remove-employee" style="visibility: hidden;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                
                                <div class="form-group">
                                    <label>Name:</label>
                                    <div class="search-input-wrapper">
                                        <i class="fas fa-search"></i>
                                        <input class="employee-search" type="text" placeholder="Search for an employee..." autocomplete="off">
                                    </div>
                                    <input type="hidden" class="employee-id" name="employee_id[]">
                                </div>

                                <!-- Remittances for this employee -->
                                <div class="remittance-lines-container">
                                    <div class="remittance-line">
                                        <div class="form-group">
                                            <label>Remittances to pay:</label>
                                            <select name="remittance_type_0[]" required>
                                                <option value="Pag-IBIG" <?php if ($active_type == 'Pag-IBIG') echo 'selected'; ?>>Pag-IBIG</option>
                                                <option value="SSS" <?php if ($active_type == 'SSS') echo 'selected'; ?>>SSS</option>
                                                <option value="PhilHealth" <?php if ($active_type == 'PhilHealth') echo 'selected'; ?>>PhilHealth</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Input Amount:</label>
                                            <input type="number" step="0.01" name="amount_0[]" required placeholder="0.00">
                                        </div>
                                        <button type="button" class="btn-remove-line" style="visibility: hidden;">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </div>
                                
                                <button type="button" class="btn-add-more-remittance">ADD MORE REMITTANCES</button>
                            </div>
                        </div>

                        <button type="button" id="addEmployeeBtn" class="btn-add-more" style="margin-top: 24px; background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);">
                            <i class="fas fa-user-plus"></i> ADD ANOTHER EMPLOYEE
                        </button>

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-add">ADD ALL REMITTANCES</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
                <!-- Import Remittances Modal -->
        <div id="importRemittanceModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>IMPORT REMITTANCES</h2>
                    <span class="close-button" id="closeImportModal">&times;</span>
                </div>  
                <div class="modal-body">
                    <form id="importRemittanceForm" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Excel File (.xlsx, .xls):</label>
                            <input type="file" name="import_file" id="import_file" accept=".xlsx,.xls" required style="padding: 12px;">
                        </div>
                        
                        <div class="inline-form-groups">
                            <div class="form-group">
                                <label>Month Covered:</label>
                                <select name="import_month" required>
                                    <?php foreach($months as $num => $name): ?>
                                    <option value="<?php echo $num; ?>" <?php if($num == $filter_month) echo 'selected'; ?>><?php echo $name; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Year Covered:</label>
                                <select name="import_year" required>
                                    <?php for($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                                    <option value="<?php echo $y; ?>" <?php if($y == $filter_year) echo 'selected'; ?>><?php echo $y; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <label>Remittance Type:</label>
                            <select name="import_type" required>
                                <option value="Pag-IBIG" <?php if ($active_type == 'Pag-IBIG') echo 'selected'; ?>>Pag-IBIG</option>
                                <option value="SSS" <?php if ($active_type == 'SSS') echo 'selected'; ?>>SSS</option>
                                <option value="PhilHealth" <?php if ($active_type == 'PhilHealth') echo 'selected'; ?>>PhilHealth</option>
                            </select>
                        </div>
        
                       <div style="background: #fef3c7; border: 2px solid #fbbf24; border-radius: 12px; padding: 16px; margin: 20px 0;">
                            <p style="margin: 0; font-size: 13px; color: #92400e; font-weight: 600;">
                                <i class="fas fa-info-circle" style="margin-right: 8px;"></i>
                                CSV file should have columns: <strong>Employee ID, Amount</strong> (All imports are marked as Paid)
                            </p>
                        </div>
        
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-add">IMPORT</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@10.2.7/dist/autoComplete.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('addRemittanceModal');
    const openModalBtn = document.getElementById('openModalBtn');
    const closeButton = modal.querySelector('.close-button');
    const employeesContainer = document.getElementById('employees-container');
    const addEmployeeBtn = document.getElementById('addEmployeeBtn');
    const maxRemittancesPerEmployee = 3;
    let employeeCount = 1;
    let autoCompleteInstances = [];

    // --- Toast Notification Function ---
    function showToast(message, type = 'success') {
        const existingToast = document.querySelector('.toast-notification');
        if (existingToast) {
            existingToast.remove();
        }
        
        const toast = document.createElement('div');
        toast.className = `toast-notification ${type === 'error' ? 'error' : ''}`;
        
        const icon = type === 'success' ? 
            '<i class="fas fa-check-circle"></i>' : 
            '<i class="fas fa-exclamation-triangle"></i>';
        
        toast.innerHTML = `
            <div class="toast-icon">${icon}</div>
            <div class="toast-content">${message}</div>
            <button class="toast-close">&times;</button>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        toast.querySelector('.toast-close').onclick = function() {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        };
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 4000);
    }

    // --- Check URL parameters for success/error messages ---
    const urlParams = new URLSearchParams(window.location.search);
    
    if (urlParams.get('success') === 'true') {
        const added = urlParams.get('added') || 0;
        const employees = urlParams.get('employees') || 0;
        const emailsSent = urlParams.get('emails_sent') || 0;
        
        let message = `Successfully added ${added} remittance(s) for ${employees} employee(s).`;
        if (emailsSent > 0) {
            message += ` Email notifications sent to ${emailsSent} employee(s).`;
        }
        
        showToast(message, 'success');
    }
    
    if (urlParams.get('error')) {
        const errorMsg = urlParams.get('message') || 'An error occurred.';
        showToast(errorMsg, 'error');
    }

    // --- Initialize Autocomplete for an input ---
    function initializeAutocomplete(inputElement, hiddenIdInput) {
        const autoCompleteInstance = new autoComplete({
            selector: () => inputElement,
            placeHolder: "Search for an employee...",
            data: {
                src: async (query) => {
                    if (query.length < 1) return [];
                    try {
                        const source = await fetch(`government_beneficiary.php?action=search_employees&query=${query}`);
                        const data = await source.json();
                        return data;
                    } catch (error) {
                        console.error('Autocomplete Error:', error);
                        return [];
                    }
                },
                keys: ["name"],
                cache: false,
            },
            resultItem: { highlight: true },
            threshold: 1,
            debounce: 300,
            events: {
                input: {
                    selection: (event) => {
                        const selection = event.detail.selection.value;
                        inputElement.value = selection.name;
                        hiddenIdInput.value = selection.id;
                    }
                }
            }
        });
        
        autoCompleteInstances.push(autoCompleteInstance);
        return autoCompleteInstance;
    }

    // --- Initialize first employee's autocomplete ---
    const firstEmployeeSearch = document.querySelector('.employee-search');
    const firstEmployeeId = document.querySelector('.employee-id');
    if (firstEmployeeSearch && firstEmployeeId) {
        initializeAutocomplete(firstEmployeeSearch, firstEmployeeId);
    }

    // --- Modal open/close ---
    openModalBtn.onclick = function() { modal.style.display = 'flex'; }
    closeButton.onclick = function() { 
        modal.style.display = 'none';
        resetModal();
    }

    // --- Reset modal to initial state ---
    function resetModal() {
        const blocks = employeesContainer.querySelectorAll('.employee-block');
        for (let i = 1; i < blocks.length; i++) {
            blocks[i].remove();
        }
        
        const firstBlock = blocks[0];
        firstBlock.querySelector('.employee-search').value = '';
        firstBlock.querySelector('.employee-id').value = '';
        
        const remittanceLines = firstBlock.querySelector('.remittance-lines-container');
        const lines = remittanceLines.querySelectorAll('.remittance-line');
        for (let i = 1; i < lines.length; i++) {
            lines[i].remove();
        }
        lines[0].querySelector('input[type="number"]').value = '';
        
        employeeCount = 1;
        updateEmployeeNumbers();
        updateAllRemoveButtons();
    }

    // --- Add new employee block ---
    addEmployeeBtn.addEventListener('click', function() {
        const firstBlock = employeesContainer.querySelector('.employee-block');
        const newBlock = firstBlock.cloneNode(true);
        
        newBlock.querySelector('.employee-search').value = '';
        newBlock.querySelector('.employee-id').value = '';
        
        const remittanceLines = newBlock.querySelector('.remittance-lines-container');
        const lines = remittanceLines.querySelectorAll('.remittance-line');
        
        for (let i = 1; i < lines.length; i++) {
            lines[i].remove();
        }
        
        const firstLine = lines[0];
        firstLine.querySelector('input[type="number"]').value = '';
        firstLine.querySelector('select').name = `remittance_type_${employeeCount}[]`;
        firstLine.querySelector('input[type="number"]').name = `amount_${employeeCount}[]`;
        
        const newSearch = newBlock.querySelector('.employee-search');
        const newId = newBlock.querySelector('.employee-id');
        initializeAutocomplete(newSearch, newId);
        
        const removeBtn = newBlock.querySelector('.btn-remove-employee');
        removeBtn.addEventListener('click', function() {
            newBlock.remove();
            updateEmployeeNumbers();
            updateAllRemoveButtons();
        });
        
        employeesContainer.appendChild(newBlock);
        
        setupRemittanceButtons(newBlock, employeeCount);
        
        employeeCount++;
        updateEmployeeNumbers();
        updateAllRemoveButtons();
    });

    // --- Setup remittance add/remove buttons for an employee block ---
    function setupRemittanceButtons(block, empIndex) {
        const addMoreBtn = block.querySelector('.btn-add-more-remittance');
        const container = block.querySelector('.remittance-lines-container');
        
        container.querySelectorAll('.remittance-line .btn-remove-line').forEach(btn => {
            btn.onclick = () => {
                btn.parentElement.remove();
                updateRemittanceButtons(block);
            };
        });
        
        addMoreBtn.addEventListener('click', function() {
            const lines = container.querySelectorAll('.remittance-line');
            if (lines.length >= maxRemittancesPerEmployee) return;
            
            const firstLine = lines[0];
            const newLine = firstLine.cloneNode(true);
            newLine.querySelector('input[type="number"]').value = '';
            newLine.querySelector('select').name = `remittance_type_${empIndex}[]`;
            newLine.querySelector('input[type="number"]').name = `amount_${empIndex}[]`;
            
            const removeBtn = newLine.querySelector('.btn-remove-line');
            removeBtn.addEventListener('click', () => {
                newLine.remove();
                updateRemittanceButtons(block);
            });
            
            container.appendChild(newLine);
            updateRemittanceButtons(block);
        });
        
        updateRemittanceButtons(block);
    }

    // --- Update remittance line remove buttons visibility ---
    function updateRemittanceButtons(block) {
        const container = block.querySelector('.remittance-lines-container');
        const lines = container.querySelectorAll('.remittance-line');
        const addBtn = block.querySelector('.btn-add-more-remittance');
        
        lines.forEach((line) => {
            const removeBtn = line.querySelector('.btn-remove-line');
            if (removeBtn) {
                removeBtn.style.visibility = lines.length > 1 ? 'visible' : 'hidden';
            }
        });
        
        addBtn.style.display = lines.length >= maxRemittancesPerEmployee ? 'none' : 'inline-flex';
    }

    // --- Update all remove buttons for all blocks ---
    function updateAllRemoveButtons() {
        const blocks = employeesContainer.querySelectorAll('.employee-block');
        blocks.forEach((block) => {
            const removeEmployeeBtn = block.querySelector('.btn-remove-employee');
            if (removeEmployeeBtn) {
                removeEmployeeBtn.style.visibility = blocks.length > 1 ? 'visible' : 'hidden';
            }
            updateRemittanceButtons(block);
        });
    }

    // --- Update employee numbers in headers and input names ---
    function updateEmployeeNumbers() {
        const blocks = employeesContainer.querySelectorAll('.employee-block');
        employeeCount = blocks.length;
        blocks.forEach((block, index) => {
            block.querySelector('.employee-block-header h3').textContent = `Employee #${index + 1}`;
            
            const remittanceLines = block.querySelectorAll('.remittance-line');
            remittanceLines.forEach(line => {
                const typeSelect = line.querySelector('select');
                const amountInput = line.querySelector('input[type="number"]');
                if(typeSelect) typeSelect.name = `remittance_type_${index}[]`;
                if(amountInput) amountInput.name = `amount_${index}[]`;
            });
        });
    }

    // --- Setup initial buttons ---
    const firstBlock = employeesContainer.querySelector('.employee-block');
    if (firstBlock) {
        setupRemittanceButtons(firstBlock, 0);
    }

    // --- Auto-submit form when month/year filter changes ---
    const monthFilter = document.getElementById('monthFilter');
    const yearFilter = document.getElementById('yearFilter');
    if (monthFilter) monthFilter.addEventListener('change', () => monthFilter.form.submit());
    if (yearFilter) yearFilter.addEventListener('change', () => yearFilter.form.submit());

    // --- Import Modal functionality ---
    const importModal = document.getElementById('importRemittanceModal');
    const openImportModalBtn = document.getElementById('openImportModalBtn');
    const closeImportModal = document.getElementById('closeImportModal');

    if (openImportModalBtn) {
        openImportModalBtn.onclick = function() { importModal.style.display = 'flex'; }
    }
    if (closeImportModal) {
        closeImportModal.onclick = function() { importModal.style.display = 'none'; }
    }
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
            resetModal();
        }
        if (event.target == importModal) {
            importModal.style.display = 'none';
        }
    }

    // --- Import Form Submission ---
    const importForm = document.getElementById('importRemittanceForm');
    if (importForm) {
        importForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'IMPORTING...';
            
            fetch('import_remittances.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    importModal.style.display = 'none';
                    importForm.reset();
                    
                    setTimeout(() => {
                        location.reload();
                    }, 4400);
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('An error occurred during import.', 'error');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });
    }
});
</script>

</body>
</html>