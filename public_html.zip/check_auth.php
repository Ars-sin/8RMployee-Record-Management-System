<?php
// First, run the core server-side authentication check.
require_once 'check_auth_core.php';
?>